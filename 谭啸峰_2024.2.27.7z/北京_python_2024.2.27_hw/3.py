
string = input()

for i in list(string):
    print(i)
