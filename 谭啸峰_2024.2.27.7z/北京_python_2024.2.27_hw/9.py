
value = []

string = input()

for i in list(string):
    print(ord(i), end=' ')
