
string = "我的名字是张小黎"

for i in range(10):
    print(string)
