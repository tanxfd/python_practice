
S = input()
count = 0

for i in list(S):
    count += 1
    print(f"{i} {count}")