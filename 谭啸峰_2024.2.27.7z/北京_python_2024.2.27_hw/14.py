
thick = 1
count = 0

for count in range(10):
    thick *= 2

print(thick)
