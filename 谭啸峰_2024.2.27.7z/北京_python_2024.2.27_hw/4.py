
begin = int(input("输入开始的整数值"))

end = int(input("输入结束的整数值"))

for i in range(begin + 1, end):
    print(i)
