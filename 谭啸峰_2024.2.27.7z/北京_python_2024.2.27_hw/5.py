
for i in range(0, 6):
    print(2 * i)
