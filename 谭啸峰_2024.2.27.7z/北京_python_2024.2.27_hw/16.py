
count = 0

for i in range(100):
    if i % 3 != 0:
        count += i

print(count)
