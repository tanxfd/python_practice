
count = 0

for i in range(100):
    count += i
    
print(count)
