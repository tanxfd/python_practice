
list = [24, 26, 24, 25, 23, 21, 22, 23, 23]

for i in list:
    if i == 23:
        print(list.index(i))
        break

