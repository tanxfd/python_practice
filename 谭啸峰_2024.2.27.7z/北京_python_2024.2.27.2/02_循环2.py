
i = 0

while i < 10:
    print("第" + str(i + 1) + "次：你好，Python!")
    i += 1

