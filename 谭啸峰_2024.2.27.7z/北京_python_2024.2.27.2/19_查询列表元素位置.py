
l = [24, 23, 24, 25, 23, 21, 22, 23, 23]

for i, l_num in enumerate(l):
    if l_num == 23:
        print(i, end=' ')

