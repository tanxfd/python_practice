
a={'xm':'张三','xb':'男','nl':23,'sg':1.78}

key_name = input()

if key_name in a:
    print(a[key_name])
