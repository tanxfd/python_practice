
l = [25, 23, 22, 23, 33, 25, 24, 26]

for i in l:
    print(i, end=' ')
