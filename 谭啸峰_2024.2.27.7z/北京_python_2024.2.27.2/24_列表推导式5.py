
l = [24, 23, 24, 25, 23, 21, 22, 23, 23]

print([i for i, lnum in enumerate(l) if lnum == 23])
