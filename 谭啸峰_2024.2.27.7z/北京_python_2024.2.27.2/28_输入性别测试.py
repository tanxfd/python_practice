
while 1:
    gender = input("请输入你的性别:")
    if gender == "男" or gender == "女":
        print("你的性别是" + gender)
        break
    else:
        print("性别必须输入男或者女")
