
i = 100

while i < 1000:
    print(i)
    i += 1
