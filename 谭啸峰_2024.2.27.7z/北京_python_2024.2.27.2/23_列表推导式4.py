
list = [25, 23, 22, 23, 33, 25, 24, 26]
print(*[i for i in list])
