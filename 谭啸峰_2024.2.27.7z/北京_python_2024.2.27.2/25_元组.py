
t = ('张三', '男', 23, 1.78, 74.3)

for i in t:
    print(i)

print(tuple(t))
