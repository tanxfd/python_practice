
i = 0

while i < 10:
    print("你好，Python!")
    i += 1
    while i == 9:
        print("你好，Python!")
        print("程序结束")
        i += 1
