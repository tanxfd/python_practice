
sd_list = [ [1, 2, 3], [4, 5, 6], [7, 8, 9] ]
for i in sd_list:
    for j in i:
        print(j, end=' ')
