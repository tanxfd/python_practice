
print([i for i in range(20, 51)])
