
count = 0

while count <= 10000:
    donate = int(input("输入捐款金额"))
    count += donate
    print("已捐款金额为" + str(count))
